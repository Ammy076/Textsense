var tips = [
  "Take a break.",
  "Try active relaxation.",
  "Focus on your breathing.",
  "Get creative.",
  "Spend time in nature.",
  "Picture yourself somewhere serene.",
  "Listen to music.",
  "Write down your thoughts.",
  "Visualize your calm.",
  "Connect to nature.",
  "Practice mindfulness."
  "Look outside.",
  "Sniff oranges.",
  "Pet a furry friend.",
  "Discover new places.",
  "Try progressive muscle relaxation.",
  "Refocus your thoughts.",
  "Be kind to yourself."
];
