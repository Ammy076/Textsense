
import 'package:flutter/material.dart';

class LanguageDetectionPage extends StatefulWidget {
  @override
  _LanguageDetectionPageState createState() => _LanguageDetectionPageState();
}

class _LanguageDetectionPageState extends State<LanguageDetectionPage> {
  final TextEditingController _controller = TextEditingController();
  String _language = "";

  void _detectLanguage() {
    // Simulate language detection by checking for certain words
    final text = _controller.text.toLowerCase();
    if (text.contains('bonjour') || text.contains('merci')) {
      setState(() {
        _language = 'French';
      });
    } else if (text.contains('hola') || text.contains('gracias')) {
      setState(() {
        _language = 'Spanish';
      });
    } else {
      setState(() {
        _language = 'English';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Language Detection'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              decoration: InputDecoration(
                labelText: 'Enter text',
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _detectLanguage,
              child: Text('Detect Language'),
            ),
            SizedBox(height: 20),
            Text(
              'Detected Language: $_language',
              style: TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}
