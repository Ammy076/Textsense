
import 'package:flutter/material.dart';

class KeywordExtractionPage extends StatefulWidget {
  @override
  _KeywordExtractionPageState createState() => _KeywordExtractionPageState();
}

class _KeywordExtractionPageState extends State<KeywordExtractionPage> {
  final TextEditingController _controller = TextEditingController();
  String _keywords = "";

  void _extractKeywords() {
    // Simulate keyword extraction by returning the first 3 unique words
    final words = _controller.text.split(' ').toSet().toList();
    setState(() {
      _keywords = words.length > 3 ? words.take(3).join(', ') : words.join(', ');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Keyword Extraction'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              decoration: InputDecoration(
                labelText: 'Enter text',
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _extractKeywords,
              child: Text('Extract Keywords'),
            ),
            SizedBox(height: 20),
            Text(
              'Keywords: $_keywords',
              style: TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}
