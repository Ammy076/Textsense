
import 'package:flutter/material.dart';

class TextSummaryPage extends StatefulWidget {
  @override
  _TextSummaryPageState createState() => _TextSummaryPageState();
}

class _TextSummaryPageState extends State<TextSummaryPage> {
  final TextEditingController _controller = TextEditingController();
  String _summary = "";

  void _summarizeText() {
    // Simulate text summarization by taking the first 10 words
    final words = _controller.text.split(' ');
    setState(() {
      _summary = words.length > 10 ? words.take(10).join(' ') + '...' : _controller.text;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Text Summary'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              decoration: InputDecoration(
                labelText: 'Enter text',
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _summarizeText,
              child: Text('Summarize Text'),
            ),
            SizedBox(height: 20),
            Text(
              'Summary: $_summary',
              style: TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}
