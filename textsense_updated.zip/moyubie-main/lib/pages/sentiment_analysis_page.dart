
import 'package:flutter/material.dart';

class SentimentAnalysisPage extends StatefulWidget {
  @override
  _SentimentAnalysisPageState createState() => _SentimentAnalysisPageState();
}

class _SentimentAnalysisPageState extends State<SentimentAnalysisPage> {
  final TextEditingController _controller = TextEditingController();
  String _result = "";

  void _analyzeSentiment() {
    // Simulate sentiment analysis by checking for positive/negative keywords
    final text = _controller.text.toLowerCase();
    if (text.contains('love') || text.contains('fantastic')) {
      setState(() {
        _result = 'Positive';
      });
    } else if (text.contains('hate') || text.contains('worst')) {
      setState(() {
        _result = 'Negative';
      });
    } else {
      setState(() {
        _result = 'Neutral';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sentiment Analysis'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              decoration: InputDecoration(
                labelText: 'Enter text',
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _analyzeSentiment,
              child: Text('Analyze Sentiment'),
            ),
            SizedBox(height: 20),
            Text(
              'Result: $_result',
              style: TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}
