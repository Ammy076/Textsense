
import 'package:flutter/material.dart';
import 'pages/sentiment_analysis_page.dart';
import 'pages/text_summary_page.dart';
import 'pages/keyword_extraction_page.dart';
import 'pages/language_detection_page.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TextSense',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomePage(),
      routes: {
        '/sentiment': (context) => SentimentAnalysisPage(),
        '/summary': (context) => TextSummaryPage(),
        '/keywords': (context) => KeywordExtractionPage(),
        '/language': (context) => LanguageDetectionPage(),
      },
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('TextSense Home'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/sentiment');
              },
              child: Text('Sentiment Analysis'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/summary');
              },
              child: Text('Text Summary'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/keywords');
              },
              child: Text('Keyword Extraction'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/language');
              },
              child: Text('Language Detection'),
            ),
          ],
        ),
      ),
    );
  }
}
