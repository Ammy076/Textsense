package com.moyuteam.moyubie

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
